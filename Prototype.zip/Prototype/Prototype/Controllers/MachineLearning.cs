﻿using Microsoft.AspNetCore.Mvc;

namespace Prototype.Controllers
{
    public class MachineLearningController : Controller
    {

        public IActionResult Index()
        {
            return View();
        }
    }
}
