﻿using Microsoft.AspNetCore.Mvc;

namespace Prototype.Controllers
{
    public class Model7 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
