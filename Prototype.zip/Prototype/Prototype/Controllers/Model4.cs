﻿using Microsoft.AspNetCore.Mvc;

namespace Prototype.Controllers
{
    public class Model4 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
