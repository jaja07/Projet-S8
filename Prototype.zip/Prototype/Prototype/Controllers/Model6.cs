﻿using Microsoft.AspNetCore.Mvc;

namespace Prototype.Controllers
{
    public class Model6 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
