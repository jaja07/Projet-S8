﻿using Microsoft.AspNetCore.Mvc;

namespace Prototype.Controllers
{
    public class Model3 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
